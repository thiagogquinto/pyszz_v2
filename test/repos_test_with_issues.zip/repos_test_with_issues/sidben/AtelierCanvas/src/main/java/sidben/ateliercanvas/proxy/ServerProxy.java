package sidben.ateliercanvas.proxy;


public class ServerProxy extends CommonProxy 
{
}
