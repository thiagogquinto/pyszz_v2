package sidben.ateliercanvas.reference;


public class BlockSide
{

    public static int BELOW = 0;
    public static int ABOVE = 1;
    
}
