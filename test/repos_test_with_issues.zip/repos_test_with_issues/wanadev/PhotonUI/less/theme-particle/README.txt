Contains the flat "particle" theme files for PhotonUI.
Compiles to photonui-theme-particle.css
See variables.less for properties you can easily change to customise 
the theme.
