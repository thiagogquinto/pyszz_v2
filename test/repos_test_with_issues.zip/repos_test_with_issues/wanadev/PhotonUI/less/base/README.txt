Contains the basic Less required by widgets without themeing.
Compiles to photonui-base.css
