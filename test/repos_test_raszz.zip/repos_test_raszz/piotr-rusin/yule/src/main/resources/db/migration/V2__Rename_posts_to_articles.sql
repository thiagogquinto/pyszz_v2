ALTER TABLE "posts" RENAME TO "articles";
