ALTER TABLE articles RENAME COLUMN publication_date TO publication_timestamp;
ALTER TABLE articles RENAME COLUMN creation_date TO creation_timestamp;
ALTER TABLE articles RENAME COLUMN modification_date TO modification_timestamp;
