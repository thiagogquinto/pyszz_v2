ALTER TABLE "articles" ADD publication_date timestamp;
