ALTER TABLE articles ADD UNIQUE (title);
ALTER TABLE articles ADD UNIQUE (slug);
