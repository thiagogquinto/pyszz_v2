UPDATE articles SET status = 'DRAFT' WHERE status = 'PRIVATE';
