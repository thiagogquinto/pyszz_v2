ALTER TABLE articles ADD publication_scheduled boolean NOT NULL DEFAULT false;
