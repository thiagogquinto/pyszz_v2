ALTER TABLE "articles" ADD status varchar(10) NOT NULL DEFAULT 'DRAFT';
