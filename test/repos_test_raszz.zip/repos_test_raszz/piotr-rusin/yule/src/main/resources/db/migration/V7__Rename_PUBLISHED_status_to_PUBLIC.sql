UPDATE articles SET status = 'PUBLIC' WHERE status = 'PUBLISHED';
