ALTER TABLE articles RENAME COLUMN introduction TO custom_introduction;
