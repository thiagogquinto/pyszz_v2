ALTER TABLE articles ADD version integer NOT NULL DEFAULT 1;
