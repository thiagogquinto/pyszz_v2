ALTER TABLE articles ADD introduction text;
