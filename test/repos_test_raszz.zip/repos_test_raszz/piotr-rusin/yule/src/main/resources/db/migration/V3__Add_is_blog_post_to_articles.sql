ALTER TABLE "articles" ADD is_blog_post boolean NOT NULL DEFAULT TRUE;
