/*
  A C-program for MT19937: Real number version interface
*/

#ifndef __RANDMT__
#define __RANDMT__

extern double genrand();
extern void   sgenrand(unsigned long seed);

#endif /* __RANDMT__ */
