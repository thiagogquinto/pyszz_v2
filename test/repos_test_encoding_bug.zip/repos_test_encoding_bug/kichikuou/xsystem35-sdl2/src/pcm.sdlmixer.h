#include <SDL_mixer.h>

extern int pcm_sdlmixer_load_chunk(int slot, Mix_Chunk *chunk);
extern Mix_Chunk *pcm_sdlmixer_load(int no);
