The test scenario file (`testSA.ALD`) in this directory should pass in both
xsystem35 and the original System 3.x.

To build `testSA.ALD`, install [xsys35c](https://github.com/kichikuou/xsys35c)
and run `xsys35c` command in this directory.
