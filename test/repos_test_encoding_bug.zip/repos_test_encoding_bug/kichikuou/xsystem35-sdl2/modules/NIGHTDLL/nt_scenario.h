#ifndef __NT_SCENARIO_H__
#define __NT_SCENARIO_H__

extern void    nt_sco_init();
extern int     nt_sco_main(int mode);
extern boolean nt_sco_is_natsu();
extern void nt_sco_callevent(int ev);

#endif /* __NT_SCENARIO_H__ */
