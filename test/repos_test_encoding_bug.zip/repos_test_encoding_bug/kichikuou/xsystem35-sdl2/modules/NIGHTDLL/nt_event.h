#ifndef __NT_EVENT_H__
#define __NT_EVENT_H__

extern void ntev_callback(agsevent_t *e);
extern void ntev_main();


#endif /* __NT_EVENT_H__ */
