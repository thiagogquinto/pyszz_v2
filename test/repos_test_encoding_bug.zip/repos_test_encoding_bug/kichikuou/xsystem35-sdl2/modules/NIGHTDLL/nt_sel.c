int ntsel_dosel(void) {
	// 選択肢を描画
	// 
	return 0;
}
